import asyncio, threading, os, random, sys, time, uuid, aiofiles, aiohttp, datetime
from aiohttp import ClientSession, ClientTimeout, TCPConnector
from asyncio import Semaphore
from urllib.parse import urlencode, urlparse
from signer.argus import Argus
from signer.ladon import Ladon
from signer.gorgon import Gorgon
from concurrent.futures import ProcessPoolExecutor
import uuid
import hashlib
import os
import requests
import gc
from multiprocessing import Lock
import time
from aiohttp import ClientSession, ClientTimeout, TCPConnector
from asyncio import Semaphore


def update_device_state_on_success(shared_state, device_id, iid, lock):
    with lock:
        shared_state.success_count += 1
        if shared_state.fixed_device_id is None:
            shared_state.fixed_device_id = device_id
            shared_state.fixed_iid = iid
            shared_state.fail_count = 0
            shared_state.mode = "fixed"
        elif shared_state.fixed_device_id == device_id:
            shared_state.fail_count = 0

def update_device_state_on_failure(shared_state, device_id, lock):
    with lock:
        if shared_state.mode == "fixed" and shared_state.fixed_device_id == device_id:
            shared_state.fail_count += 1
            if shared_state.fail_count >= 10:
                shared_state.fixed_device_id = None
                shared_state.fixed_iid = None
                shared_state.fail_count = 0
                shared_state.mode = "random"  # 👉 quay lại random

def check_key_online(key):
    try:
        res = requests.get("https://notepad.vn/share/6zQyb3j28", timeout=10)
        if res.status_code == 200:
            if key in res.text:
                print(f"[KEY] ✅ Key hợp lệ.")
                return True
            else:
                print(f"[KEY] ❌ Key không hợp lệ hoặc chưa được cấp phép. Tool sẽ dừng.")
                return False
        else:
            print(f"[KEY] ❌ Không thể kết nối tới server (status: {res.status_code})")
            return False
    except Exception as e:
        print(f"[KEY] ❌ Lỗi khi kiểm tra key: {e}")
        return False
def get_machine_id():
    system_uuid = str(uuid.getnode())
    return hashlib.sha256(system_uuid.encode()).hexdigest().upper()
# Global variables for success count, start time và video_user
start_time = time.time()

count = 0

# Additional variables
__offset = ["-28800", "-21600"]
__devices = ["SM-G9900", "SM-A136U1", "SM-M225FV", "SM-E426B", "SM-M526BR", "SM-M326B",
             "SM-A528B", "SM-F711B", "SM-F926B", "SM-A037G", "SM-A225F", "SM-M325FV",
             "SM-A226B", "SM-M426B", "SM-A525F", "SM-N976N", "SM-M526B", "SM-G570MSM",
             "SM-A520F", "SM-G975F", "SM-A215U1", "SM-A125F", "SM-J730F", "SM-A207F",
             "SM-G970F", "SM-A236B", "SM-J730F", "SM-J730F", "SM-G970F", "SM-J730F",
             "SM-J730F", "SM-J327T1", "SM-A205U", "SM-A136B", "SM-G991B", "SM-G525F",
             "SM-A528B", "SM-A528B", "SM-A528B", "SM-A136B", "SM-G900F", "SM-A226B",
             "SM-A528B", "SM-A515F", "SM-G935T", "SM-A505F", "SM-P619", "SM-N976B",
             "SM-A510M", "SM-J530FM", "SM-G998B", "SM-A500FU", "SM-G935F"]
__versionCode = ["190303", "190205", "190204", "190103", "180904", "180804", "180803", "180802", "270204"]
__versionUa = [247, 312, 322, 357, 358, 415, 422, 444, 466]
__resolution = ["900*1600", "720*1280"]
__dpi = ["240", "300"]

regions = ["DZ", "US", "GB", "FR", "DE"]
device_brands = ["OPPO", "Samsung", "Huawei", "Xiaomi", "OnePlus"]
timezones = ["Africa/Algiers", "America/New_York", "Europe/London", "Europe/Paris", "Europe/Berlin"]
android_versions = ["12", "11", "10", "9", "8.1"]
device_types = ["CPH2121", "SM-G960F", "P30", "Mi 9", "GM1900"]
builds = ["SP1A.210812.016", "RQ3A.210905.001", "QP1A.190711.020", "RP1A.200720.012"]

def generate_random_device_id():
    return str(uuid.uuid4())

def generate_timestamp():
    return str(int(time.time() * 1000))

def generate_random_user_agent():
    android_version = random.choice(android_versions)
    device_type = random.choice(device_types)
    build = random.choice(builds)
    cronet_version = f"711894ae {time.strftime('%Y-%m-%d')}"
    quic_version = f"5f987023 {time.strftime('%Y-%m-%d')}"
    return f"com.zhiliaoapp.musically/2023503040 (Linux; U; Android {android_version}; en; {device_type}; Build/{build}; Cronet/TTNetVersion:{cronet_version} QuicVersion:{quic_version})"
async def memory_cleanup_trigger(queue):
    while True:
        if queue.qsize() > 3000:
            print("[GC] 🔄 Dọn rác do queue đầy")
            gc.collect()
        await asyncio.sleep(300)
def generate_random_headers(video_id, device_id, version_name, params, unix_timestamp, app_name, shared_state=None):
    user_agent = generate_random_user_agent()
    rticket = generate_timestamp()

    params = {k: v for k, v in params.items() if v is not None}
    params_str = urlencode(params)

    use_cached = (
        shared_state and
        shared_state.fixed_device_id == device_id and
        shared_state.cached_gorgon and
        shared_state.cached_ladon and
        shared_state.cached_argus and
        shared_state.cached_params_str == params_str and
        abs(shared_state.cached_unix_timestamp - unix_timestamp) < 10
    )

    if use_cached:
        gorgon_headers = shared_state.cached_gorgon
        x_ladon = shared_state.cached_ladon
        argus = shared_state.cached_argus
    else:
        x_khronos = int(time.time())
        x_ladon = Ladon.encrypt(x_khronos, 1611921764, 1233)

        try:
            argus = Argus.get_sign(
                queryhash=f"device_id={device_id}&version_name={version_name}&video_id={video_id}",
                timestamp=unix_timestamp,
                aid=1233,
                license_id=1611921764
            )
        except Exception as e:
            print(f"Failed to generate Argus: {e}")
            argus = "default_argus"

        gorgon = Gorgon(params=params_str, unix=unix_timestamp)
        gorgon_headers = gorgon.get_value()

        if shared_state and shared_state.fixed_device_id == device_id:
            shared_state.cached_gorgon = gorgon_headers
            shared_state.cached_ladon = x_ladon
            shared_state.cached_argus = argus
            shared_state.cached_unix_timestamp = unix_timestamp
            shared_state.cached_params_str = params_str

    api_endpoints = [
        "api16-core-c-alisg.tiktokv.com",
        "api16-core-c-useast1a.tiktokv.com",
        "api16-core-va.tiktokv.com",
        "api19-core-c-useast1a.tiktokv.com",
        "api19-core-va.tiktokv.com",
        "api19-normal-c-useast1a.tiktokv.com",
        "api21-core-c-alisg.tiktokv.com",
        "api22-core-c-useast1a.tiktokv.com",
        "api22-normal-c-useast1a.tiktokv.com"
    ]
    random_endpoint = random.choice(api_endpoints)

    headers = {
        'Accept-Encoding': 'gzip',
        'Connection': 'Keep-Alive',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': f"store-idc=maliva; store-country-code-src=did; store-country-code=id; install_id={params['iid']}; ttreq=1${uuid.uuid4().hex[:16]}; odin_tt={uuid.uuid4().hex}",
        'Host': random_endpoint,
        'passport-sdk-version': '30990',
        'sdk-version': '2',
        'User-Agent': user_agent,
        'X-Argus': argus,
        'X-Gorgon': gorgon_headers['x-gorgon'],
        'X-Khronos': gorgon_headers['x-khronos'],
        'X-SS-REQ-TICKET': gorgon_headers['x-ss-req-ticket'],
        'X-Ladon': x_ladon,
        'X-SS-STUB': 'ABAB9C45B6F5F3593F021D37AF534D94',
        'x-tt-req-timeout': '90000',
        'x-tt-store-region': 'id',
        'x-tt-store-region-src': 'did',
        'x-tt-ultra-lite': '1',
        'x-vc-bdturing-sdk-version': '2.3.2.118n',
        'appName': app_name,
        'Device-ID': str(device_id)
    }

    return headers


# device_list = open('device_list_1.txt', 'r', encoding='utf-8').read().split('\n')

# Biến toàn cục để giữ device_id & iid tốt
# ... (các import giữ nguyên như bạn gửi ban đầu)

# Biến toàn cục để giữ device_id & iid tốt
current_device_id = None
current_iid = None

async def send_tiktok_request(session, video_id, video_user, semaphore, app_name, shared_state, lock):
    async with semaphore:
        try:
            # Sử dụng fixed device_id nếu hợp lệ
            use_fixed = False

            with lock:
                if shared_state.mode == "fixed" and shared_state.fixed_device_id and shared_state.fail_count < 3:
                    device_id = shared_state.fixed_device_id
                    iid = shared_state.fixed_iid
                    use_fixed = True
                elif shared_state.mode == "random":
                    device_id = random.randint(10**18, 10**19 - 1)
                    iid = random.randint(10**18, 10**19 - 1)
                else:
                    return  # Khi đang fixed mà fail_count >= 3 → dừng hẳn, chờ reset
            if device_id is None or iid is None:
                return

            # Setup thông tin thiết bị
            rticket = generate_timestamp()
            ts = generate_timestamp()
            first_install_time = str(int(ts) - random.randint(100000, 200000))
            last_install_time = str(int(ts) - random.randint(50000, 100000))
            session_id = generate_timestamp()
            region = "DE"
            device_brand = "asus"
            timezone = "Africa/Harare"
            device_type = "ASUS_Z01QD"
            version_name = "34.8.2"

            params = {
                'os_api': "25",
                'device_type': device_type,
                'ssmix': "a",
                'manifest_version_code': "340802",
                'dpi': random.choice(__dpi),
                'region': region,
                'carrier_region': region,
                'app_name': app_name,
                'version_name': version_name,
                'timezone_offset': random.choice(__offset),
                'ts': ts,
                'ab_version': version_name,
                'ac2': "wifi",
                'ac': "wifi",
                'app_type': "normal",
                'host_abi': "x86",
                'channel': "googleplay",
                'update_version_code': random.choice(__versionCode),
                '_rticket': rticket,
                'device_platform': "android",
                'iid': iid,
                'build_number': version_name,
                'locale': "de-DE",
                'op_region': region,
                'version_code': random.choice(__versionCode),
                'timezone_name': timezone,
                'cdid': str(uuid.uuid4()),
                'openudid': uuid.uuid4().hex[:16],
                'device_id': device_id,
                'sys_region': region,
                'app_language': "de",
                'resolution': random.choice(__resolution),
                'device_brand': device_brand,
                'language': "de",
                'os_version': "7.1.2",
                'aid': "1340"
            }

            params = {k: v for k, v in params.items() if v is not None}
            api_endpoints = [
                "api16-core-c-alisg.tiktokv.com",
                "api16-core-c-useast1a.tiktokv.com",
                "api16-core-va.tiktokv.com",
                "api19-core-c-useast1a.tiktokv.com",
                "api19-core-va.tiktokv.com",
                "api19-normal-c-useast1a.tiktokv.com",
                "api21-core-c-alisg.tiktokv.com",
                "api22-core-c-useast1a.tiktokv.com",
                "api22-normal-c-useast1a.tiktokv.com"
            ]
            random_endpoint = random.choice(api_endpoints)
            url = f"https://{random_endpoint}/aweme/v1/aweme/stats/"
            unix_timestamp = int(time.time())
            params_str = urlencode(params)

            if (
                shared_state.fixed_device_id == device_id and
                shared_state.cached_headers is not None and
                shared_state.cached_params_str == params_str
            ):
                headers = shared_state.cached_headers
            else:
                headers = generate_random_headers(video_id, device_id, version_name, params, unix_timestamp, app_name, shared_state)

                # Nếu đang dùng fixed device thì cache lại headers
                if shared_state.fixed_device_id == device_id:
                    shared_state.cached_headers = headers
                    shared_state.cached_params_str = params_str
            parsed_url = urlparse(url)
            headers['Host'] = parsed_url.netloc

            payload = {
                "order": "1",
                "first_install_time": first_install_time,
                "request_id": "",
                "is_ad": "false",
                "follow_status": "0",
                "tab_type": "0",
                "aweme_type": "0",
                "item_id": video_id,
                "impr_order": "1",
                "sync_origin": "false",
                "pre_item_playtime": "",
                "follower_status": "0",
                "session_id": session_id,
                "pre_hot_sentence": "",
                "pre_item_id": "",
                "play_delta": "1",
                "action_time": ts,
                "item_source_category": "1",
                "item_distribute_source": "for_you_page"
            }

            # Bắt đầu gọi request
            try:
                async with session.post(url, params=params, data=payload, headers=headers) as response:
                    try:
                        if session.closed:
                            return
                        if response.status == 200:
                            json_response = await response.json()
                            response_str = str(json_response)

                            if json_response.get("status_code") == 0 and response_str.startswith("{'status_code': 0"):
                                update_device_state_on_success(shared_state, device_id, iid, lock)
                                with lock:
                                    print(f"[✅] Đã tăng 1 view cho video | Tổng: {shared_state.success_count}")
                            else:
                                update_device_state_on_failure(shared_state, device_id, lock)
                        else:
                            update_device_state_on_failure(shared_state, device_id, lock)
                    except Exception:
                        update_device_state_on_failure(shared_state, device_id, lock)
                    finally:
                        await response.release()
            except aiohttp.ClientConnectionError:
                pass

        except Exception:
            pass  # tránh crash process nếu có lỗi bất ngờ


async def producer(queue, shared_state, lock, video_id, video_user, app_name):
    """
    Phiên bản tăng tốc random:
    - Random device nhanh, không chờ lâu
    - Khi fixed device lỗi vài lần => random lại ngay
    - Khi random tìm được device ổn => giữ tạm 1 thời gian ngắn rồi random tiếp
    """
    good_streak = 0
    idle_ticks = 0
    while True:
        try:
            mode = shared_state.mode

            # Nếu đang random, đẩy mạnh random nhanh hơn
            if mode == "random":
                await queue.put((video_id, video_user, app_name))
                idle_ticks = 0

            # Nếu đang fixed mà vẫn ổn thì vẫn tiếp tục đẩy job
            elif mode == "fixed" and shared_state.fail_count < 3:
                await queue.put((video_id, video_user, app_name))
                good_streak += 1
                idle_ticks = 0

                # Sau khi chạy ổn liên tục 200 vòng thì chủ động random lại
                if good_streak >= 200:
                    with lock:
                        shared_state.mode = "random"
                        shared_state.fixed_device_id = None
                        shared_state.fixed_iid = None
                        shared_state.fail_count = 0
                    # print("[🚀] Chủ động random lại sau khi chạy ổn lâu")
                    good_streak = 0

            else:
                # Nếu bị lỗi nhiều hoặc đứng, reset lại random ngay
                idle_ticks += 1
                if idle_ticks >= 100:  # chỉ 0.5s
                    with lock:
                        shared_state.mode = "random"
                        shared_state.fixed_device_id = None
                        shared_state.fixed_iid = None
                        shared_state.fail_count = 0
                    # print("[♻️] Reset nhanh sang random vì device kém hoặc đứng")
                    idle_ticks = 0

            await asyncio.sleep(0.001)  # cực ngắn để random nhanh hơn
        except Exception as e:
            print(f"[Producer] lỗi: {e}")
            await asyncio.sleep(0.2)



async def worker(name, queue, session, semaphore, shared_state, lock):
    while True:
        video_id, video_user, app_name = await queue.get()
        try:
            async with semaphore:
                await send_tiktok_request(session, video_id, video_user, semaphore, app_name, shared_state, lock)
        except Exception as e:
            print(f"[{name}] ❌ Error: {e}")
        finally:
            queue.task_done()




async def main(video_id, video_user, app_name, shared_state, lock):
    connector = TCPConnector(limit_per_host=200)
    timeout = ClientTimeout(total=5)
    session = ClientSession(connector=connector, timeout=timeout)
    semaphore = Semaphore(200)  # Giới hạn coroutine đồng thời
    queue = asyncio.Queue()

    # Memory cleanup nếu queue đầy
    asyncio.create_task(memory_cleanup_trigger(queue))

    # Producer — đẩy job vào queue
    asyncio.create_task(producer(queue, shared_state, lock, video_id, video_user, app_name))

    # Tạo 100 worker coroutine
    for i in range(200):
        asyncio.create_task(worker(f"Worker-{i}", queue, session, semaphore, shared_state, lock))

    # 🔁 Vòng lặp giữ cho process không thoát
    try:
        await asyncio.Future()  # giữ loop sống, có thể cancel
    except asyncio.CancelledError:
        pass
    finally:
        await session.close()



def start(video_id, video_user, shared_state,lock):
    app_name = "musically_go"
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(main(video_id, video_user, app_name, shared_state,lock))

if __name__ == "__main__":
    from multiprocessing import freeze_support
    freeze_support()
    import threading
    from multiprocessing import Manager, Lock, Process
    import signal

    machine_key = get_machine_id()
    print(f"[KEY] 🔑 Machine Key: {machine_key}")

    # if not check_key_online(machine_key):
    #     input("Nhấn Enter để thoát...")
    #     exit(1)

    print("[KEY] ✅ Key hợp lệ. Tiếp tục chạy tool...\n")

    # Nhập thông tin video
    video_url = input("Nhập Link Video Cần Tăng View: ").strip()
    parsed = urlparse(video_url)
    parts = parsed.path.split('/')
    if len(parts) >= 4:
        video_user = parts[1]
        video_id = parts[3]
    else:
        print("URL không hợp lệ!")
        sys.exit(1)

    process_count = 6


    # Tạo biến dùng chung giữa các tiến trình
    manager = Manager()
    shared_state = manager.Namespace()
    lock = Lock()

    shared_state.device_id = None
    shared_state.iid = None
    shared_state.success_count = 0
    shared_state.cached_headers = None
    shared_state.cached_params_str = None
    shared_state.random_allowed = True
    shared_state.mode = "random"   # "random" hoặc "fixed"
    shared_state.fixed_device_id = None
    shared_state.fixed_iid = None
    shared_state.fail_count = 0
    shared_state.cached_gorgon = None
    shared_state.cached_ladon = None
    shared_state.cached_argus = None
    shared_state.cached_unix_timestamp = 0
    shared_state.cached_params_str = ""
    # UI realtime

    # Khởi tạo tiến trình song song
    processes = []
    for _ in range(process_count):
        p = Process(target=start, args=(video_id, video_user, shared_state, lock))
        p.start()
        processes.append(p)

    # Xử lý tín hiệu dừng (Ctrl+C)
    def shutdown(signum, frame):
        print("\n[🔴] Nhận tín hiệu dừng, đang đóng tiến trình...")
        for p in processes:
            if p.is_alive():
                p.join(timeout=2)   # ✅ chờ tiến trình tự dừng
        os._exit(0)


    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    for p in processes:
        p.join()
