package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	HOST             = "api19.tiktokv.com"
	REQ_TIMEOUT      = 5 * int64(time.Second)
	PROGRESS_REFRESH = 250 * time.Millisecond
)

var (
	VERSIONS       = []int{247, 312, 322, 357, 358, 415, 422, 444, 466}
	DEVICES        = []string{}
	TIKTOK_DEVICES []TikTokDevice
	deviceCounter  int64
	deviceMutex    sync.Mutex
	videoRegex     = regexp.MustCompile(`(?:/video/|v=)(\d{10,30})`)
)

type Logger struct {
	mu sync.Mutex
}

func (l *Logger) Info(format string, args ...interface{}) {
	l.mu.Lock()
	defer l.mu.Unlock()
	fmt.Printf("%s - INFO - %s\n", time.Now().Format(time.RFC3339), fmt.Sprintf(format, args...))
}

func (l *Logger) Error(format string, args ...interface{}) {
}

var logger = &Logger{}

type Metrics struct {
	Success int64
	Failed  int64
	Timeout int64
	Errors  int64
	mu      sync.Mutex
}

type TikTokDevice struct {
	DeviceID    string `json:"device_id"`
	IID         string `json:"iid"`
	DeviceType  string `json:"device_type"`
	DeviceBrand string `json:"device_brand"`
	OSVersion   string `json:"os_version"`
	VersionCode string `json:"version_code"`
	Region      string `json:"region"`
	Channel     string `json:"channel"`
	AppName     string `json:"app_name"`
	UserAgent   string `json:"user_agent"`
}

func ExtractVideoID(link string) (string, error) {
	link = strings.TrimSpace(link)

	if matched, _ := regexp.MatchString(`^\d{10,30}$`, link); matched {
		return link, nil
	}

	if !strings.Contains(link, "tiktok.com/") {
		logger.Error("Invalid TikTok URL provided: %s", link)
		return "", errors.New("invalid TikTok URL")
	}

	client := &http.Client{
		Timeout: time.Second * 10,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 5 {
				return errors.New("too many redirects")
			}
			return nil
		},
	}

	resp, err := client.Get(link)
	if err != nil {
		logger.Error("Error extracting video ID from %s: %v", link, err)
		return "", err
	}
	defer resp.Body.Close()

	finalURL := resp.Request.URL.String()
	matches := videoRegex.FindStringSubmatch(finalURL)
	if len(matches) < 2 {
		logger.Error("Could not extract video ID from URL: %s", finalURL)
		return "", errors.New("could not extract video ID")
	}

	return matches[1], nil
}

func getNextDevice() TikTokDevice {
	deviceMutex.Lock()
	defer deviceMutex.Unlock()

	if len(TIKTOK_DEVICES) == 0 {
		// Fallback to hardcoded values if no devices loaded
		return TikTokDevice{
			DeviceID: "7522057963538187792",
			IID:      "7522059562116957969",
		}
	}

	device := TIKTOK_DEVICES[deviceCounter%int64(len(TIKTOK_DEVICES))]
	deviceCounter++
	return device
}

func SendView(client *http.Client, videoID string, metrics *Metrics) {
	version := VERSIONS[rand.Intn(len(VERSIONS))]
	tiktokDevice := getNextDevice()
	osVersion := rand.Intn(7) + 5

	params := url.Values{
		"app_language":    {"fr"},
		"iid":             {tiktokDevice.IID},
		"device_id":       {tiktokDevice.DeviceID},
		"channel":         {tiktokDevice.Channel},
		"device_type":     {tiktokDevice.DeviceType},
		"ac":              {"wifi"},
		"os_version":      {strconv.Itoa(osVersion)},
		"version_code":    {strconv.Itoa(version)},
		"app_name":        {tiktokDevice.AppName},
		"device_brand":    {tiktokDevice.DeviceBrand},
		"ssmix":           {"a"},
		"device_platform": {"android"},
		"aid":             {"1180"},
		"as":              {"a1iosdfgh"},
		"cp":              {"androide1"},
	}

	headers := map[string]string{
		"Host":            HOST,
		"Connection":      "keep-alive",
		"Accept-Encoding": "gzip",
		"X-SS-REQ-TICKET": strconv.FormatInt(time.Now().UnixMilli(), 10),
		"Content-Type":    "application/x-www-form-urlencoded; charset=UTF-8",
		"User-Agent":      tiktokDevice.UserAgent,
	}

	data := url.Values{
		"manifest_version_code": {strconv.Itoa(version)},
		"update_version_code":   {strconv.Itoa(version) + "0"},
		"play_delta":            {"1"},
		"item_id":               {videoID},
		"version_code":          {strconv.Itoa(version)},
		"aweme_type":            {"0"},
	}

	urlStr := fmt.Sprintf("https://%s/aweme/v1/aweme/stats?%s", HOST, params.Encode())
	req, err := http.NewRequest("POST", urlStr, bytes.NewBufferString(data.Encode()))
	if err != nil {
		metrics.mu.Lock()
		metrics.Errors++
		metrics.mu.Unlock()
		return
	}

	for k, v := range headers {
		req.Header.Set(k, v)
	}

	resp, err := client.Do(req)
	if err != nil {
		if strings.Contains(err.Error(), "timeout") {
			metrics.mu.Lock()
			metrics.Timeout++
			metrics.mu.Unlock()
		} else {
			metrics.mu.Lock()
			metrics.Errors++
			metrics.mu.Unlock()
		}
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode == 200 && strings.Contains(resp.Header.Get("Content-Type"), "charset=utf-8") {
		metrics.mu.Lock()
		metrics.Success++
		metrics.mu.Unlock()
	} else {
		metrics.mu.Lock()
		metrics.Failed++
		metrics.mu.Unlock()
	}
}

func Worker(sem chan struct{}, client *http.Client, videoID string, target int, metrics *Metrics, wg *sync.WaitGroup) {
	defer wg.Done()

	for {
		select {
		case sem <- struct{}{}:
			metrics.mu.Lock()
			if metrics.Success >= int64(target) {
				metrics.mu.Unlock()
				<-sem
				return
			}
			metrics.mu.Unlock()

			SendView(client, videoID, metrics)
			<-sem
		}
	}
}

func Run(videoID string, target int, threads int) (int64, error) {
	startTime := time.Now()
	metrics := &Metrics{}
	wg := &sync.WaitGroup{}
	sem := make(chan struct{}, threads)

	client := &http.Client{
		Timeout: time.Duration(REQ_TIMEOUT),
	}

	done := make(chan struct{})
	go func() {
		ticker := time.NewTicker(PROGRESS_REFRESH)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				metrics.mu.Lock()
				elapsed := time.Since(startTime).Seconds()
				ratePer2Sec := 0.0
				if elapsed > 0 {
					ratePer2Sec = float64(metrics.Success) / elapsed * 2
				}
				fmt.Printf("\r\x1b[38;2;155;155;255mfuck\x1b[0m - module: views | count : %d/%d | views rate : %.0f per second",
					metrics.Success, target, ratePer2Sec)
				metrics.mu.Unlock()
			case <-done:
				return
			}
		}
	}()

	for i := 0; i < threads; i++ {
		wg.Add(1)
		go Worker(sem, client, videoID, target, metrics, wg)
	}

	wg.Wait()
	close(done)

	metrics.mu.Lock()
	elapsed := time.Since(startTime).Seconds()
	ratePer2Sec := 0.0
	if elapsed > 0 {
		ratePer2Sec = float64(metrics.Success) / elapsed * 2
	}
	fmt.Printf("\r\x1b[38;2;155;155;255mfuck\x1b[0m - module: views | count : %d/%d | views rate : %.0f per second\n",
		metrics.Success, target, ratePer2Sec)
	metrics.mu.Unlock()

	return metrics.Success, nil
}

func loadDevices() error {
	var jsonPath string

	if exePath, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exePath)
		jsonPath = filepath.Join(exeDir, "models.json")
		if _, err := os.Stat(jsonPath); err != nil {
			jsonPath = "models.json"
		}
	} else {
		jsonPath = "models.json"
	}

	data, err := os.ReadFile(jsonPath)
	if err != nil {
		return fmt.Errorf("failed to read models.json: %v", err)
	}

	if err := json.Unmarshal(data, &DEVICES); err != nil {
		return fmt.Errorf("failed to parse models.json: %v", err)
	}

	if len(DEVICES) == 0 {
		return fmt.Errorf("no devices found in models.json")
	}

	return nil
}

func loadTikTokDevices() error {
	var txtPath string

	if exePath, err := os.Executable(); err == nil {
		exeDir := filepath.Dir(exePath)
		txtPath = filepath.Join(exeDir, "devices.txt")
		if _, err := os.Stat(txtPath); err != nil {
			txtPath = "devices.txt"
		}
	} else {
		txtPath = "devices.txt"
	}

	file, err := os.Open(txtPath)
	if err != nil {
		return fmt.Errorf("failed to open devices.txt: %v", err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		// Try JSON format first
		var device TikTokDevice
		if err := json.Unmarshal([]byte(line), &device); err == nil && device.DeviceID != "" {
			// Set defaults for missing fields
			if device.Channel == "" {
				device.Channel = "googleplay"
			}
			if device.AppName == "" {
				device.AppName = "trill"
			}
			if device.UserAgent == "" {
				device.UserAgent = fmt.Sprintf("com.ss.android.ugc.trill/%s (Linux; Android 11; fr_FR; %s; Build/RP1A.200720.012; Cronet/58.0.2991.0)",
					device.VersionCode, device.DeviceType)
			}
			TIKTOK_DEVICES = append(TIKTOK_DEVICES, device)
			continue
		}

		// Parse colon-separated format: device_id:iid:device_type:device_brand:cdid:openudid
		parts := strings.Split(line, ":")
		if len(parts) < 4 {
			continue
		}

		device = TikTokDevice{
			DeviceID:    parts[0],
			IID:         parts[1],
			DeviceType:  parts[2],
			DeviceBrand: parts[3],
			Channel:     "googleplay",
			AppName:     "trill",
			VersionCode: "300804",
			Region:      "US",
		}
		device.OSVersion = strconv.Itoa(rand.Intn(5) + 10) // Android 10-14
		device.UserAgent = fmt.Sprintf("com.ss.android.ugc.trill/300804 (Linux; U; Android %s; en_US; %s; Build/RP1A.200720.012; Cronet/58.0.2991.0)",
			device.OSVersion, device.DeviceType)

		TIKTOK_DEVICES = append(TIKTOK_DEVICES, device)
	}

	if err := scanner.Err(); err != nil {
		return fmt.Errorf("error reading devices.txt: %v", err)
	}

	if len(TIKTOK_DEVICES) == 0 {
		return fmt.Errorf("no valid devices found in devices.txt")
	}

	return nil
}

func clearConsole() {
	switch runtime.GOOS {
	case "windows":
		cmd := exec.Command("cmd", "/c", "cls")
		cmd.Stdout = os.Stdout
		cmd.Run()
	default:
		fmt.Print("\033[2J\033[H")
	}
}

func runCLI() {
	rand.Seed(time.Now().UnixNano())
	clearConsole()

	if err := loadDevices(); err != nil {
		fmt.Printf("\x1b[33m[!] Warning: %v\x1b[0m\n", err)
	}

	if err := loadTikTokDevices(); err != nil {
		fmt.Printf("\x1b[33m[!] Warning: %v\x1b[0m\n", err)
	}

	reader := bufio.NewReader(os.Stdin)

	// 1. Nhập Video ID/Link
	fmt.Print("\x1b[38;2;155;155;255m[>]\x1b[0m Enter TikTok video link or video ID: ")
	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)

	if input == "" {
		fmt.Println("\x1b[31m[!] Error: No video link or ID provided.\x1b[0m")
		return
	}

	// 2. Nhập số lượng view (mặc định 100k nếu nhấn Enter)
	fmt.Print("\x1b[38;2;155;155;255m[>]\x1b[0m Enter number of views (default 100000): ")
	viewsStr, _ := reader.ReadString('\n')
	views := 100000
	if v, err := strconv.Atoi(strings.TrimSpace(viewsStr)); err == nil && v > 0 {
		views = v
	}

	// 3. THIẾT LẬP LUỒNG MẶC ĐỊNH (Không hỏi người dùng)
	threads := 10000 

	videoID, err := ExtractVideoID(input)
	if err != nil {
		fmt.Printf("\x1b[31m[!] Invalid TikTok link/ID: %v\x1b[0m\n", err)
		return
	}

	fmt.Printf("\n\x1b[32m[✓]\x1b[0m Video ID: %s\n", videoID)
	fmt.Printf("\x1b[32m[✓]\x1b[0m Target views: %d\n", views)
	fmt.Printf("\x1b[32m[✓]\x1b[0m Threads (Auto): %d\n\n", threads)

	viewsSent, err := Run(videoID, views, threads)
	if err != nil {
		fmt.Printf("\x1b[31m[!] Error: %v\x1b[0m\n", err)
		return
	}

	fmt.Printf("\n\x1b[32m[✓] Successfully sent %d views to video %s\x1b[0m\n", viewsSent, videoID)
}

func main() {
	runCLI()
}
