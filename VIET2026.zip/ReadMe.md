make new folder e.g 'tiktok bots' add all the downloaded files into that folder do NOT leave any out MUST have go.mod, go.sum, models gen and ttviews then after this is 
done do the steps below

run the gen.go name the file devices.txt or this will NOT work itll auto make folder + file after it generates devices for you (recommended 1 mil devices)
move devices.txt from saved devices folder into same directory / folder as ttviews.go and then run ttviews.go and enter video id/url and itll ask for how much views you want
this is a real view count you want 1 mil views pick 1 mil youll get 90% of the 1 mil.

enjoy the bot ;)

these bots are made by discord.gg/tikpy