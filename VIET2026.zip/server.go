package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
	"strconv"
	"sync"
)

type Job struct {
	URL   string `json:"url"`
	Views int    `json:"views"`
}

var (
	taskQueue     = make(chan Job, 100)
	activeJobs    = make([]Job, 0)
	maxConcurrent = 1
	lock          sync.Mutex
)

func runTool(job Job) {

	fmt.Println("▶️ Start:", job.URL, job.Views)

	cmd := exec.Command("go", "run", "ttviews.go")

	stdin, _ := cmd.StdinPipe()

	go func() {
		defer stdin.Close()
		fmt.Fprintln(stdin, job.URL)
		fmt.Fprintln(stdin, job.Views)
		fmt.Fprintln(stdin, 2000)
	}()

	cmd.Stdout = nil
	cmd.Stderr = nil

	err := cmd.Run()
	if err != nil {
		fmt.Println("❌ Error:", err)
	}

	fmt.Println("✅ Done:", job.URL)
}

func worker(id int) {
	for job := range taskQueue {

		lock.Lock()
		activeJobs = append(activeJobs, job)
		lock.Unlock()

		fmt.Printf("🚀 Worker-%d running %s\n", id, job.URL)

		runTool(job)

		lock.Lock()
		for i, j := range activeJobs {
			if j.URL == job.URL {
				activeJobs = append(activeJobs[:i], activeJobs[i+1:]...)
				break
			}
		}
		lock.Unlock()

		fmt.Printf("🏁 Worker-%d done\n", id)
	}
}

func runHandler(w http.ResponseWriter, r *http.Request) {

	var job Job
	err := json.NewDecoder(r.Body).Decode(&job)

	if err != nil || job.URL == "" || job.Views <= 0 {
		http.Error(w, "Invalid request", 400)
		return
	}

	taskQueue <- job

	lock.Lock()
	position := len(taskQueue)
	lock.Unlock()

	resp := map[string]interface{}{
		"status": "queued",
		"queue":  position,
	}

	json.NewEncoder(w).Encode(resp)
}

func statusHandler(w http.ResponseWriter, r *http.Request) {

	lock.Lock()
	defer lock.Unlock()

	resp := map[string]interface{}{
		"running":      activeJobs,
		"queue_length": len(taskQueue),
	}

	json.NewEncoder(w).Encode(resp)
}

func formHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method == "GET" {
		w.Header().Set("Content-Type", "text/html")
		fmt.Fprint(w, htmlPage) // Đã đổi từ Fprintf sang Fprint
		return
	}

	if r.Method == "POST" {

		url := r.FormValue("url")
		viewsStr := r.FormValue("views")

		views, _ := strconv.Atoi(viewsStr)

		if url == "" || views <= 0 {
			fmt.Fprintf(w, "❌ Invalid input")
			return
		}

		job := Job{
			URL:   url,
			Views: views,
		}

		taskQueue <- job

		fmt.Fprintf(w, "✅ Job added! Link: %s Views: %d", url, views)
	}
}

var htmlPage = `<!DOCTYPE html>
<html>
<head>
<title>TikTok View Bot</title>
<style>
body{
font-family:Arial;
background:#111;
color:white;
text-align:center;
margin-top:100px;
}
input{
padding:10px;
width:400px;
margin:10px;
border-radius:5px;
border:none;
}
button{
padding:10px 20px;
background:#00ff9d;
border:none;
border-radius:5px;
font-size:16px;
cursor:pointer;
}
</style>
</head>

<body>

<h1>🔥 TikTok View Tool</h1>

<form method="POST">

<input name="url" placeholder="Enter TikTok link"><br>

<input name="views" placeholder="Views amount"><br>

<button type="submit">Run</button>

</form>

</body>
</html>`

func main() {

	for i := 1; i <= maxConcurrent; i++ {
		go worker(i)
	}

	http.HandleFunc("/", formHandler)
	http.HandleFunc("/run", runHandler)
	http.HandleFunc("/status", statusHandler)

	fmt.Println("🔥 Server running at http://0.0.0.0:5000")

	http.ListenAndServe(":5000", nil)
}
