package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os/exec"
	"sync"
)

type Job struct {
	URL   string `json:"url"`
	Views int    `json:"views"`
}

var (
	taskQueue     = make(chan Job, 100)
	activeJobs    = make([]Job, 0)
	maxConcurrent = 1
	lock          sync.Mutex
)


// ===== RUN TOOL (GỌI ttviews.go) =====
func runTool(job Job) error {

	fmt.Println("▶ Running:", job.URL, job.Views)

	cmd := exec.Command("go", "run", "ttviews.go")

	// truyền input vào stdin (giống như bạn nhập tay)
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}

	go func() {
		defer stdin.Close()
		fmt.Fprintln(stdin, job.URL)
		fmt.Fprintln(stdin, job.Views)
	}()

	cmd.Stdout = nil
	cmd.Stderr = nil

	return cmd.Run()
}


// ===== WORKER =====
func worker(id int) {
	for job := range taskQueue {

		lock.Lock()
		activeJobs = append(activeJobs, job)
		lock.Unlock()

		fmt.Printf("[Worker-%d] Start %s\n", id, job.URL)

		runTool(job)

		lock.Lock()
		// remove job
		for i, j := range activeJobs {
			if j.URL == job.URL && j.Views == job.Views {
				activeJobs = append(activeJobs[:i], activeJobs[i+1:]...)
				break
			}
		}
		lock.Unlock()

		fmt.Printf("[Worker-%d] Done\n", id)
	}
}


// ===== API /run =====
func runHandler(w http.ResponseWriter, r *http.Request) {

	if r.Method != http.MethodPost {
		http.Error(w, "Only POST allowed", 405)
		return
	}

	var job Job
	if err := json.NewDecoder(r.Body).Decode(&job); err != nil {
		http.Error(w, "Invalid JSON", 400)
		return
	}

	if job.URL == "" || job.Views <= 0 {
		http.Error(w, "Missing url or views", 400)
		return
	}

	lock.Lock()
	queueLen := len(taskQueue)
	running := len(activeJobs)
	lock.Unlock()

	taskQueue <- job

	status := "queued"
	if running < maxConcurrent {
		status = "started"
	}

	response := map[string]interface{}{
		"status":       status,
		"url":          job.URL,
		"views":        job.Views,
		"queue_length": queueLen + 1,
	}

	json.NewEncoder(w).Encode(response)
}


// ===== API /status =====
func statusHandler(w http.ResponseWriter, r *http.Request) {

	lock.Lock()
	defer lock.Unlock()

	status := "idle"
	if len(activeJobs) > 0 {
		status = "running"
	}

	response := map[string]interface{}{
		"status":       status,
		"running":      activeJobs,
		"queue_length": len(taskQueue),
	}

	json.NewEncoder(w).Encode(response)
}


// ===== MAIN =====
func main() {

	// start worker
	for i := 1; i <= maxConcurrent; i++ {
		go worker(i)
	}

	http.HandleFunc("/run", runHandler)
	http.HandleFunc("/status", statusHandler)

	fmt.Println("🚀 API Server running at :5000")
	log.Fatal(http.ListenAndServe(":5000", nil))
}