package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os/exec"
	"sync"
)

type Job struct {
	URL   string `json:"url"`
	Views int    `json:"views"`
}

var (
	taskQueue     = make(chan Job, 1000)
	activeJobs    = make([]Job, 0)
	maxConcurrent = 1
	lock          sync.Mutex
)

// ====== CHẠY ttviews.go ======
func runTool(job Job) {
	fmt.Println("▶️ Start:", job.URL, job.Views)

	cmd := exec.Command("go", "run", "ttviews.go")

	stdin, _ := cmd.StdinPipe()

	go func() {
		defer stdin.Close()
		fmt.Fprintln(stdin, job.URL)
		fmt.Fprintln(stdin, job.Views)
		fmt.Fprintln(stdin, 20000) // threads mặc định
	}()

	cmd.Stdout = nil
	cmd.Stderr = nil

	err := cmd.Run()
	if err != nil {
		fmt.Println("❌ Error:", err)
	}

	fmt.Println("✅ Done:", job.URL)
}

// ====== WORKER ======
func worker(id int) {
	for job := range taskQueue {

		lock.Lock()
		activeJobs = append(activeJobs, job)
		lock.Unlock()

		fmt.Printf("🚀 Worker-%d running %s\n", id, job.URL)

		runTool(job)

		lock.Lock()
		for i, j := range activeJobs {
			if j.URL == job.URL {
				activeJobs = append(activeJobs[:i], activeJobs[i+1:]...)
				break
			}
		}
		lock.Unlock()

		fmt.Printf("🏁 Worker-%d done\n", id)
	}
}

// ====== API /run ======
func runHandler(w http.ResponseWriter, r *http.Request) {

	var job Job
	err := json.NewDecoder(r.Body).Decode(&job)
	if err != nil || job.URL == "" || job.Views <= 0 {
		http.Error(w, "Thiếu url hoặc views", 400)
		return
	}

	taskQueue <- job

	lock.Lock()
	position := len(taskQueue)
	running := len(activeJobs)
	lock.Unlock()

	status := "queued"
	if running < maxConcurrent {
		status = "started"
	}

	response := map[string]interface{}{
		"status":  status,
		"message": fmt.Sprintf("Đã nhận yêu cầu. Vị trí hàng chờ: %d", position),
	}

	json.NewEncoder(w).Encode(response)
}

// ====== API /status ======
func statusHandler(w http.ResponseWriter, r *http.Request) {

	lock.Lock()
	defer lock.Unlock()

	status := "idle"
	if len(activeJobs) > 0 {
		status = "running"
	}

	response := map[string]interface{}{
		"status":       status,
		"running":      activeJobs,
		"queue_length": len(taskQueue),
	}

	json.NewEncoder(w).Encode(response)
}

// ====== MAIN ======
func main() {

	for i := 1; i <= maxConcurrent; i++ {
		go worker(i)
	}

	http.HandleFunc("/run", runHandler)
	http.HandleFunc("/status", statusHandler)

	fmt.Println("🔥 API running at :5000")
	http.ListenAndServe(":5000", nil)
}