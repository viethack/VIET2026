package main

import (
	"bufio"
	crand "crypto/rand"
	"fmt"
	"math/rand"
	mrand "math/rand"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"github.com/fatih/color"
)

// ---------- THREAD CONFIG ----------
const MAX_THREADS = 5000

var (
	printLock sync.Mutex
	fileLock  sync.Mutex
	counter   int64
	amount    int
)

// ---------- COLOR POOL ----------
var colors = []*color.Color{
	color.New(color.FgGreen),
	color.New(color.FgBlue),
	color.New(color.FgRed),
	color.New(color.FgMagenta),
	color.New(color.FgCyan),
	color.New(color.FgYellow),
	color.New(color.FgWhite),
}

// ---------- DEVICE POOLS ----------
type DeviceModel struct {
	Model string
	Brand string
	Res   string
	DPI   string
}

var androidModels = []DeviceModel{
	{"SM-F926B", "samsung", "1080x2400", "480"},
	{"SM-G998B", "samsung", "1440x3200", "560"},
	{"SM-G991B", "samsung", "1080x2400", "420"},
	{"SM-A536B", "samsung", "1080x2400", "400"},
	{"SM-A546B", "samsung", "1080x2400", "400"},
	{"SM-S918B", "samsung", "1440x3120", "550"},
	{"SM-G781B", "samsung", "1080x2400", "420"},
	{"Pixel 7", "google", "1080x2400", "440"},
	{"Pixel 6", "google", "1080x2400", "440"},
	{"Pixel 8", "google", "1080x2400", "480"},
	{"Pixel 8 Pro", "google", "1440x3120", "550"},
	{"Pixel 7a", "google", "1080x2400", "440"},
	{"Redmi Note 12", "xiaomi", "1080x2400", "440"},
	{"Redmi Note 11", "xiaomi", "1080x2400", "400"},
	{"Redmi Note 13", "xiaomi", "1080x2400", "440"},
	{"POCO F5", "xiaomi", "1080x2400", "440"},
	{"POCO F6", "xiaomi", "1080x2400", "440"},
	{"POCO X5", "xiaomi", "1080x2400", "440"},
	{"OnePlus 11", "oneplus", "1440x3216", "525"},
	{"OnePlus 10", "oneplus", "1440x3216", "525"},
	{"OnePlus 12", "oneplus", "1440x3216", "525"},
	{"OnePlus 9", "oneplus", "1440x3216", "525"},
	{"OPPO Find X5", "oppo", "1080x2400", "450"},
	{"OPPO Find X6", "oppo", "1080x2400", "450"},
	{"OPPO Reno 8", "oppo", "1080x2400", "450"},
	{"vivo X80", "vivo", "1080x2400", "440"},
	{"vivo X90", "vivo", "1080x2400", "440"},
	{"vivo Y78", "vivo", "1080x2400", "400"},
	{"Honor 70", "honor", "1080x2400", "430"},
	{"Honor 90", "honor", "1080x2400", "430"},
	{"Honor Magic5", "honor", "1080x2400", "430"},
	{"Nothing Phone (2)", "nothing", "1080x2400", "440"},
	{"Nothing Phone (1)", "nothing", "1080x2400", "440"},
	{"Realme GT 2", "realme", "1080x2400", "440"},
	{"Realme 11", "realme", "1080x2400", "400"},
	{"Motorola Edge 40", "motorola", "1080x2400", "440"},
	{"Motorola Razr 40", "motorola", "1080x2400", "440"},
	{"Sony Xperia 1 V", "sony", "1080x2400", "440"},
	{"Sony Xperia 5 V", "sony", "1080x2400", "440"},
	{"Nokia X30", "nokia", "1080x2400", "400"},
	{"Nokia G60", "nokia", "1080x2400", "400"},
}

var iosModels = []DeviceModel{
	{"iPhone14,5", "apple", "1170x2532", "460"},
	{"iPhone14,2", "apple", "1170x2532", "460"},
	{"iPhone14,3", "apple", "1170x2532", "460"},
	{"iPhone14,4", "apple", "1170x2532", "460"},
	{"iPhone14,6", "apple", "1170x2532", "460"},
	{"iPhone14,7", "apple", "1170x2532", "460"},
	{"iPhone14,8", "apple", "1284x2778", "458"},
	{"iPad13,4", "apple", "2048x2732", "320"},
	{"iPad13,1", "apple", "1640x2360", "264"},
	{"iPad13,2", "apple", "1640x2360", "264"},
	{"iPad13,10", "apple", "2388x1668", "264"},
	{"iPad13,11", "apple", "2388x1668", "264"},
}

var laptopModels = []DeviceModel{
	{"MacBookPro18,1", "apple", "2560x1600", "220"},
	{"MacBookPro18,2", "apple", "3024x1964", "254"},
	{"MacBookPro18,3", "apple", "3456x2234", "254"},
	{"MacBookPro18,4", "apple", "3024x1964", "254"},
	{"MacBookAir10,1", "apple", "2560x1600", "227"},
	{"XPS-15-9520", "dell", "1920x1200", "180"},
	{"XPS-13-9310", "dell", "1920x1200", "166"},
	{"ThinkPad-X1-Carbon-Gen10", "lenovo", "1920x1200", "170"},
	{"ThinkPad-X1-Carbon-Gen9", "lenovo", "1920x1200", "170"},
	{"Surface-Laptop-5", "microsoft", "2256x1504", "201"},
	{"Surface-Pro-9", "microsoft", "2688x1920", "267"},
	{"HP-Spectre-x360", "hp", "1920x1280", "166"},
	{"ASUS-ZenBook", "asus", "1920x1200", "166"},
}

var timezones = []string{
	"Europe/Paris", "Europe/London", "Europe/Berlin", "Europe/Rome", "Europe/Madrid", "Europe/Amsterdam",
	"Europe/Stockholm", "Europe/Warsaw", "Europe/Prague", "Europe/Vienna", "Europe/Zurich", "Europe/Brussels",
	"Asia/Kolkata", "Asia/Tokyo", "Asia/Shanghai", "Asia/Hong_Kong", "Asia/Singapore", "Asia/Seoul",
	"Asia/Bangkok", "Asia/Jakarta", "Asia/Manila", "Asia/Kuala_Lumpur", "Asia/Taipei", "Asia/Dubai",
	"America/New_York", "America/Los_Angeles", "America/Chicago", "America/Denver", "America/Phoenix",
	"America/Toronto", "America/Mexico_City", "America/Sao_Paulo", "America/Buenos_Aires", "America/Lima",
	"Africa/Cairo", "Africa/Lagos", "Africa/Johannesburg", "Africa/Nairobi", "Africa/Casablanca",
	"Australia/Sydney", "Australia/Melbourne", "Australia/Perth", "Australia/Brisbane", "Australia/Adelaide",
	"Pacific/Auckland", "Pacific/Fiji", "Pacific/Guam", "Pacific/Honolulu",
}

var regions = []string{
	"US", "CA", "GB", "DE", "FR", "IT", "ES", "NL", "SE", "NO", "DK", "FI", "PL", "CZ", "AT", "CH", "BE",
	"IN", "CN", "JP", "KR", "SG", "TH", "ID", "MY", "PH", "VN", "TW", "HK", "AE", "SA", "IL",
	"BR", "AR", "MX", "CO", "PE", "CL", "VE", "EC", "BO", "UY", "PY",
	"ZA", "EG", "NG", "KE", "MA", "GH", "TN", "DZ", "AO", "ET", "TZ", "UG",
	"AU", "NZ", "FJ", "PG", "GU", "HI", "FJ", "SB", "VU", "NC", "PF",
	"RU", "TR", "UA", "KZ", "UZ", "KG", "TJ", "TM", "GE", "AM", "AZ",
}

// ---------- HELPERS ----------
func randDigits(n int) string {
	if n <= 0 {
		return ""
	}
	digits := "0123456789"
	result := make([]byte, n)
	crand.Read(result) // Use crypto/rand for better randomness
	for i, b := range result {
		result[i] = digits[b%byte(len(digits))]
	}
	return string(result)
}

func generateDevice() string {
	// Pre-select random indices for better performance
	deviceType := mrand.Intn(3)
	var model, brand, res, dpi, osVersion, ua, channel string

	switch deviceType {
	case 0: // Android
		idx := mrand.Intn(len(androidModels))
		selected := androidModels[idx]
		model, brand, res, dpi = selected.Model, selected.Brand, selected.Res, selected.DPI
		osVersions := []string{"10", "11", "12", "13", "14"}
		osVersion = osVersions[rand.Intn(len(osVersions))]
		ua = fmt.Sprintf("com.ss.android.ugc.trill/300804 (Linux; U; Android %s; en_US; %s; Build/RP1A.200720.012; Cronet/58.0.2991.0)", osVersion, model)
		channel = "googleplay"
	case 1: // iOS
		idx := mrand.Intn(len(iosModels))
		selected := iosModels[idx]
		model, brand, res, dpi = selected.Model, selected.Brand, selected.Res, selected.DPI
		osVersions := []string{"14.8", "15.6", "16.2", "17.0"}
		osVersion = osVersions[rand.Intn(len(osVersions))]
		ua = fmt.Sprintf("Trill/300804 (iOS %s)", osVersion)
		channel = "appstore"
	default: // Laptop
		idx := mrand.Intn(len(laptopModels))
		selected := laptopModels[idx]
		model, brand, res, dpi = selected.Model, selected.Brand, selected.Res, selected.DPI
		osVersions := []string{"10", "11", "12"}
		osVersion = osVersions[rand.Intn(len(osVersions))]
		ua = fmt.Sprintf("Mozilla/5.0 (%s; OS %s)", brand, osVersion)
		channel = "desktop"
	}

	regionIdx := mrand.Intn(len(regions))
	region := regions[regionIdx]
	tzIdx := mrand.Intn(len(timezones))
	tz := timezones[tzIdx]

	// Generate identifiers more efficiently
	deviceID := randDigits(19)
	iid := randDigits(19)
	cdid := generateUUID() + randDigits(6)
	openudid := generateTokenHex(20)

	return fmt.Sprintf(`{"device_id": "%s", "iid": "%s", "device_type": "%s", "device_brand": "%s", "cdid": "%s", "openudid": "%s", "cookie": "", "os_version": "%s", "version_code": "300804", "version_name": "3.0.1.0", "update_version_code": "300804", "manifest_version_code": "3008040", "resolution": "%s", "dpi": "%s", "aid": "1180", "channel": "%s", "app_name": "trill", "region": "%s", "sys_region": "%s", "carrier_region": "%s", "timezone_name": "%s", "timezone_offset": "%d", "user_agent": "%s", "device_token": "", "report_token": ""}`,
		deviceID, iid, model, brand, cdid, openudid, osVersion, res, dpi, channel, region, region, region, tz, mrand.Intn(10000), ua)
}

func generateUUID() string {
	// Simple UUID-like generator
	uuid := make([]byte, 36)
	for i := range uuid {
		if i == 8 || i == 13 || i == 18 || i == 23 {
			uuid[i] = '-'
		} else {
			uuid[i] = "0123456789abcdef"[mrand.Intn(16)]
		}
	}
	return string(uuid)
}

func generateTokenHex(n int) string {
	hex := "0123456789abcdef"
	result := make([]byte, n)
	for i := range result {
		result[i] = hex[mrand.Intn(len(hex))]
	}
	return string(result)
}

// ---------- WORKER ----------
func worker(wg *sync.WaitGroup, output *os.File, workerID int) {
	defer wg.Done()
	device := generateDevice()

	// Batch write to reduce lock contention
	fileLock.Lock()
	output.WriteString(device + "\n")
	fileLock.Unlock()

	// Atomic counter for better performance
	count := atomic.AddInt64(&counter, 1)

	// Update display every 50 devices with rotating colors for speed impression
	if count%50 == 0 || count == int64(amount) {
		printLock.Lock()
		colorIndex := int(count) % len(colors)
		colors[colorIndex].Printf("\rAmount Devices Generated: %d", count)
		printLock.Unlock()
	}
}

func main() {
	mrand.Seed(time.Now().UnixNano())

	// ---------- AUTO FILE GENERATION ----------
	color.Cyan("[+] file name to auto make + save devices to ? [+] ")
	var fileNameInput string
	fmt.Scanln(&fileNameInput)

	// Validate filename
	if fileNameInput == "" {
		color.Red("[+] Error: Filename cannot be empty. Please try again.\n")
		return
	}

	// Create "saved devices" folder if it doesn't exist
	savedDevicesDir := "saved devices"
	if err := os.MkdirAll(savedDevicesDir, 0755); err != nil {
		fmt.Printf("Error creating directory: %v\n", err)
		return
	}

	fileName := filepath.Join(savedDevicesDir, fileNameInput)
	color.Yellow("[+] Auto-saving to: %s [+]\n", fileName)

	color.Cyan("[+] how many devices to generate ? [+] ")
	var amountStr string
	fmt.Scanln(&amountStr)
	amount, _ = strconv.Atoi(amountStr)

	// ---------- FILE OPEN ----------
	output, err := os.Create(fileName)
	if err != nil {
		fmt.Printf("Error creating file: %v\n", err)
		return
	}
	defer output.Close()
	writer := bufio.NewWriterSize(output, 32*1024*1024) // 32MB buffer for maximum performance
	defer writer.Flush()

	// ---------- EXECUTION ----------
	var wg sync.WaitGroup
	semaphore := make(chan struct{}, MAX_THREADS)

	// Pre-generate random seeds for better performance
	for i := 0; i < amount; i++ {
		wg.Add(1)
		semaphore <- struct{}{} // Acquire

		go func(workerID int) {
			defer func() { <-semaphore }() // Release
			worker(&wg, output, workerID)
		}(i)
	}

	wg.Wait()

	fmt.Printf("\n")
	color.Green("\n[✓] ALL DEVICES GENERATED SUCCESSFULLY\n")
	color.Green("[✓] Saved to: %s\n", fileName)
}
